// Made with Blockbench 4.12.6
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports


public class Car_brand<T extends Car> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("modid", "car_brand"), "main");
	private final ModelPart bone;
	private final ModelPart bb_main;

	public Car_brand(ModelPart root) {
		this.bone = root.getChild("bone");
		this.bb_main = root.getChild("bb_main");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition bone = partdefinition.addOrReplaceChild("bone", CubeListBuilder.create().texOffs(-27, -27).addBox(-1.0F, -16.0F, -12.0F, 2.0F, 16.0F, 29.0F, new CubeDeformation(0.0F)), PartPose.offset(-8.0F, 20.0F, 0.0F));

		PartDefinition bb_main = partdefinition.addOrReplaceChild("bb_main", CubeListBuilder.create().texOffs(-41, -34).addBox(-8.0F, -5.0F, -16.0F, 24.0F, 1.0F, 36.0F, new CubeDeformation(0.0F))
		.texOffs(-28, -21).addBox(-8.0F, -28.0F, -4.0F, 24.0F, 1.0F, 23.0F, new CubeDeformation(0.0F))
		.texOffs(0, 0).addBox(-7.0F, -28.0F, 17.0F, 2.0F, 23.0F, 2.0F, new CubeDeformation(0.0F))
		.texOffs(0, 0).addBox(14.0F, -27.0F, 17.0F, 2.0F, 22.0F, 2.0F, new CubeDeformation(0.0F))
		.texOffs(-4, 0).addBox(-5.0F, -18.0F, 17.0F, 20.0F, 13.0F, 2.0F, new CubeDeformation(0.0F))
		.texOffs(-22, -17).addBox(-6.0F, -8.0F, -9.0F, 16.0F, 2.0F, 19.0F, new CubeDeformation(0.0F))
		.texOffs(-26, -26).addBox(16.0F, -20.0F, -11.0F, 2.0F, 16.0F, 28.0F, new CubeDeformation(0.0F))
		.texOffs(4, 2).addBox(-5.0F, -1.0F, 0.0F, 0.0F, 0.0F, 0.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 24.0F, 0.0F));

		PartDefinition U_r1 = bb_main.addOrReplaceChild("U_r1", CubeListBuilder.create().texOffs(-22, -17).addBox(-6.0F, -2.0F, -9.0F, 16.0F, 2.0F, 19.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, -15.0F, 11.0F, 1.309F, 0.0F, 0.0F));

		PartDefinition cube_r1 = bb_main.addOrReplaceChild("cube_r1", CubeListBuilder.create().texOffs(-4, 0).addBox(-5.0F, -12.0F, -2.0F, 20.0F, 13.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, -6.0F, -13.0F, -0.5236F, 0.0F, 0.0F));

		PartDefinition cube_r2 = bb_main.addOrReplaceChild("cube_r2", CubeListBuilder.create().texOffs(0, 0).addBox(-1.0F, -14.0F, -1.0F, 2.0F, 27.0F, 2.0F, new CubeDeformation(0.0F))
		.texOffs(0, 0).addBox(-21.0F, -14.0F, -1.0F, 2.0F, 27.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(15.0F, -15.0F, -9.0F, -0.5236F, 0.0F, 0.0F));

		return LayerDefinition.create(meshdefinition, 16, 16);
	}

	@Override
	public void setupAnim(Car entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {

	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
		bone.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		bb_main.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}
}